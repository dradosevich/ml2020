
# you cannot use PCA library 
import numpy as np
import matplotlib.pyplot as plt

# 
data = np.genfromtxt('crimerate.csv', delimiter=',')
sample = data[:,0:-1]
label = data[:,-1]
[n,p] = sample.shape


# implement K-means from scratch. you can use library to measure L2 distance.  
# apply K-means on "sample" 
......
......
......

# project "sample" into a 2D feature space obtained by PCA 
# if you are confident about your own implementation in hw9, use it 
# otherwise, you can use PCA library
......
......
...... 

# color your instances based on your clustering results 
......
......
...... 

