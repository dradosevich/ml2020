
import numpy as np
from sklearn import linear_model
from sklearn.metrics import mean_squared_error

data = np.loadtxt('crimerate.csv', delimiter=',')

sample = data[:,0:-1] # first p-1 columns are features
label = data[:,-1] # last column is label

[n,p] = sample.shape

# start with a small training set (overfitting)
# 0.01 - 0.5
n_train = int(n*0.01)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# first, select a model (a function with unknown parameters and learner with unknown hyper-parameters)
# alpha can be intepreted as domain of parameters 
# 0.1 - 100
model = linear_model.Ridge(alpha = 0.1) 

# train the model 
model.fit(sample_train, label_train)

# apply the model to make predictions 
label_pred_train = model.predict(sample_train)
label_pred_test = model.predict(sample_test)


mse_train = mean_squared_error(label_train,label_pred_train)
mse_test = mean_squared_error(label_test,label_pred_test)

print('\nmse_train = %f' % mse_train)
print('mse_test  = %f' % mse_test)






