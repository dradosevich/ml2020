
import pandas as pd 

# this is the COMPAS data set (recidivism prediction)
data = pd.read_csv("compas.csv") 

# drop duplicate rows
data.drop_duplicates(keep = False, inplace = True) 

sample = data[:,0:-1] 
label = data[:,-1] 
[n,p] = sample.shape

# let us use 75% for training 
n_train = int(n*0.75)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# now, build your kNN classifier (or, kkNN classifier)...
# basically, you may want to first compute a n-by-m distance matrix, 
# where n is the number of training instances and m is number of testing instances 

#......

#......

#......

# now get your testing error, store it for different K, and prepare to plot a figure

# ......

# ......

