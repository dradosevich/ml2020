
import numpy as np

# this is the COMPAS data set (recidivism prediction)
data = np.loadtxt('compas.csv', delimiter=',')

sample = data[:,0:-1] 
label = data[:,-1] 
[n,p] = sample.shape

# a standard split is 75% for training and 25% for testing 
# previously, we use 1% for training in order to show overfitting 
n_train = int(n*0.75)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# now, build your KRR, AKRR and (if you choose to) AKRR+

......

......

......

# here, evaluate testing MSE and training MSE 

krr_mse_train = 
krr_mse_test = 

akrr_mse_train = 
akrr_mse_test = 

akrrp_mse_train = 
akrrp_mse_test = 






