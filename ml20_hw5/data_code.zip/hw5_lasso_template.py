
import numpy as np
from sklearn import linear_model
from sklearn.metrics import mean_squared_error

data = np.loadtxt('crimerate.csv', delimiter=',')

sample = data[:,0:-1] 
label = data[:,-1] 

[n,p] = sample.shape

n_train = int(n*0.01)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# randomly initialize beta

......

......

# implement lasso
# you should record training & testing MSEs after every update (for Figure 1 plotting)
# you should also record the number of non-zero elements in beta after every update

...... 

...... 

# Figure 1: plot your historical training MSE and testing MSE into two curves 

......

......

# Figure 2: plot your number of non-zero elements in beta 

......

......

# For Figure 3, you will need to run multiple times with different lambda's and plot the converged results

.......

# For Figure 4, you will need to run multiple times with different lambda's and plot the converged results

.......








