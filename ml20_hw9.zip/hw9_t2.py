
# you cannot use PCA library 
import numpy as np
import matplotlib.pyplot as plt

# 
data = np.genfromtxt('crimerate.csv', delimiter=',')
sample = data[:,0:-1]
label = data[:,-1]
[n,p] = sample.shape



# let's learn PCA vectors from the entire sample set (i.e., "sample")
# note that label is not used -- therefore PCA is an "unsuperivsed learning" technique 
# cannot use PCA libraries; can use libraries to find eigenvectors/eigenvalues of a matrix
......
......
......



# you will find p number of PCA projection vectors w1, w2, ..., wp
# we stypically store them in a p-by-k matrix "w"; each column being one vector
# typically, vectors are sorted in a way that, 1st column is the optimal, 2nd column is the 2nd optimal, etc 
# tip: many libraries will automatically sort eigenvectors based on their eigenvalues 
w = .....



# Plot Figure 1 based on w1 and w2 
sample_pca_1 = ...... # this is a n-by-1 vector; each row is one instance and the value is its projection on w1 (1st pca feature) 
sample_pca_2 = ...... # same, but projection on w2
# now, plot data distribution based on these two features 
......
......
......



# Plot Figure 2 based on w(p-1) and wp
sample_pca_p_1 = ...... # same, but projection on w(p-1)
sample_pca_p = ...... # same, but projection on wp
# now plot data distribution based on these two features 
......
......
......

 

