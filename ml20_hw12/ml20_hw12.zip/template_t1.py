
import pandas as pd 

# this is the COMPAS data set (recidivism prediction)
data = pd.read_csv("compas.csv") 

# drop duplicate rows
data.drop_duplicates(keep = False, inplace = True) 

sample = data[:,0:-1] 
label = data[:,-1] 
[n,p] = sample.shape

# choose the percentage of classification methods yourself 
n_train = int(n*_____)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# now, implement logistic regression 
# you may want to implement both optimization methods inside the same loop to save time 
# remember to store your training errors of both methods after one update 


#......

#......

#......

# now plot the two convergence curves 

# ......

# ......

