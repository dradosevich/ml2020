
import numpy as np
from sklearn import linear_model
from sklearn.metrics import mean_squared_error

data = np.loadtxt('crimerate.csv', delimiter=',')

sample = data[:,0:-1] 
label = data[:,-1] 

[n,p] = sample.shape

n_train = int(n*0.01)

sample_train = sample[0:n_train,:]
sample_test = sample[n_train:,:]

label_train = label[0:n_train]
label_test = label[n_train:]

# create an array of weights w, and then preset its values 
# for example, the weight of x_i is w_i = 1.  

...... 

...... 

# now, implement your WRR from scratch -- do not use libraries for instance weight or model regularization

......

......

# apply your model to make prediction 
# get (i) total MSE; (ii) minority MSE; (iii) non-minority MSE 
# you cannot use library to do evaluation; need to implement this part from scratch 

......

......

# plot your results
# properly label your figures and show proper legends 

......

......






