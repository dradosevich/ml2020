
# you cannot use PCA library 
import numpy as np
import matplotlib.pyplot as plt

# 
data = np.genfromtxt('crimerate.csv', delimiter=',')
sample = data[:,0:-1]
label = data[:,-1]
[n,p] = sample.shape


# in this task, we will consider a prediction problem 
# let's first split data into training and testing sets 
sample_train = sample[0:int(0.75*n),:]
label_train = label[0:int(0.75*n)]
sample_test = sample[int(0.75*n):,:]
label_test = label[int(0.75*n):]


# let's learn PCA projection vectors from the training sample (i.e., "sample_train") 
# question: why not use testing sample? 
# note: still not using any label 
......
......
......
# store your k projection vectors in a matrix "w_train" (similar to w in [2])
# note: here you need to vary k to get different prediction mse  
w_train = ...



# next, project both training sample and testing sample onto w_train
# both training and testing instances will now have dimension "k"
samle_train_pca = ....
samle_test_pca = ....


# finally, build your prediction model from (sample_train_pca, label_train) 
# and evaluate your model on (sample_test_pca, label_test) 
# train a linear regression model using least square 
# you can use libraries to implement this part (including model training and evaluating)
......
......
......
......
......




# Plot Figure 1 based on w1 and w2 
sample_pca_1 = ...... # this is a n-by-1 vector; each row is one instance and the value is its projection on w1 (1st pca feature) 
sample_pca_2 = ...... # same, but projection on w2
# now, plot data distribution based on these two features 
......
......
......



# Plot Figure 2 based on w(p-1) and wp
sample_pca_p_1 = ...... # same, but projection on w(p-1)
sample_pca_p = ...... # same, but projection on wp
# now plot data distribution based on these two features 
......
......
......

 

